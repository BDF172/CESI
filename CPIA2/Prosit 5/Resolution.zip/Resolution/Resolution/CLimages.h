#pragma once

namespace NS_composants
{
	public ref class CLimages
	{
	public:
		System::Drawing::Bitmap^ acquisitionImage(System::String^);
	};
}
