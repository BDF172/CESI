#pragma once

void showErrorMessage(System::String^ toShow);