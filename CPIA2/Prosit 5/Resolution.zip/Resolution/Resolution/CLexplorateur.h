#pragma once

namespace NS_composants
{
	ref class CLfichier
	{
	public:
		array<System::String^>^ explorerUnDossier(System::String^);
		void effacer(System::String^);
		void copier(System::String^, System::String^);
	};
}
